<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://fonts.googleapis.com/css?family=Poppins:100,300,400,700,900" rel="stylesheet">
        <link rel="stylesheet" href="css/icon-font.css">
        <link rel="stylesheet" href="css/style.css">   
        <link rel="stylesheet" href="css/fancybox.min.css">
        <link rel="stylesheet" href="css/swiper.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/odometer.min.css">
        <link rel="stylesheet" href="css/swiper.min.css">
        <link rel="stylesheet" href="css/flaticon.css">
        <title>Contacts Form - Industen</title>
        <link rel="shortcut icon" type="image/png" href="img/favicon.png">
        <meta name="description" content="Contact Form">
    </head>
    <body>
    <div class="preloader">
        <figure> <img src="img/loader.png" alt="Image"> </figure>
    </div>
    <div class="page-transition"></div>
    <aside class="side-widget">
        <div class="inner">
            <!-- Logo Menu Mobile -->
            <div class="show-mobile">
                <div class="site-menu">
                    <ul class="menu">
                        <li><a href="index.html">Inicio</a></li>
                        <li><a href="about-us.html">Sobre Nosotros</a></li>
                        <li><a href="services.html">Servicios </a><span class="sb" style="font-size: 18px">+</span>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="estacion-servicio.html">Estacion de Servicios</a>
                                </li>
                                <li><a class="dropdown-item" href="maquinaria-pesada.html">Maquinas Pesadas</a></li>
                                <li><a class="dropdown-item" href="servicio-carga.html">Transporte de Carga</a></li>
                            </ul>
                        </li>
                        <!--  <li><a href="projects.html">Projects</a></li>
                        <li><a href="faq.html">Faq</a></li>
                        <li><a href="blog.html">Blog</a></li> -->
                        <li><a href="contact-us.html">Contacto</a></li>
                        <li><a href="https://www.visor.jadal.pe/">Comprobante Electrónico</a></li>
                        <li><a href="http://200.37.70.234/Reports_SQLEXPRESS2015/Pages/Report.aspx?ItemPath=%2fConsultaExterna%2flogin"
                                target="_blank">Portal Cliente</a></li>
                        <li><a href="http://192.168.18.13:5173/auth/login/" target="_blank">Intranet</a></li>

                    </ul>
                </div>
            </div>
            <small>© 2023 - Jadal Software</small>
        </div>
    </aside>
    <nav class="navbar">
        <div class="container">
            <!-- Logo Menu Desktop -->
            <div class="logo"> <a href="index.html"><img src="img/logo.png" alt="Image"></a> </div>
            <div class="site-menu">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <a href="http://200.37.70.234/Reports_SQLEXPRESS2015/Pages/Report.aspx?ItemPath=%2fConsultaExterna%2flogin"
                                target="_blank" class="iconrenk">
                                <i class="flaticon-team icontop"></i>
                                <img src="img/icon-s.png" class="ics" alt="">
                                <div class="idl">
                                    <strong>Portal Cliente</strong>
                                    <br>Conoce tus consumos
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4">
                            <a href="https://www.visor.jadal.pe/" target="_blank" class="iconrenk">
                                <i class="flaticon-invoice icontop"></i>
                                <img src="img/icon-s.png" class="ics" alt="">
                                <div class="idl">
                                    <strong>Comprobante Electrónico</strong>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4">
                            <a href="http://192.168.18.13:5173/auth/login/" target="_blank" class="iconrenk">
                                <i class="flaticon-team-2 icontop1"></i>
                                <img src="img/icon-s.png" class="ics" alt="">
                                <div class="idl3">
                                    <strong>Intranet</strong><br>Acceso corportivo &nbsp;&nbsp;&nbsp;&nbsp;
                                </div>
                            </a>
                        </div>


                    </div>
                </div>
                <ul class="menueffect">
                    <li><a href="index.html">Inicio</a></li>
                    <li><a href="about-us.html">Sobre Nosotros</a></li>
                    <li><a href="services.html">Servicios +</a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="estacion-servicio.html">Estacion de Servicios</a>
                            </li>
                            <li><a class="dropdown-item" href="maquinaria-pesada.html">Maquinas Pesadas</a></li>
                            <li><a class="dropdown-item" href="servicio-carga.html">Transporte de Carga</a></li>
                        </ul>
                    </li>
                    <!--  <li><a href="projects.html">Projects</a></li>
                    <li><a href="faq.html">Frequently Questions</a></li>
                    <li><a href="blog.html">Blog</a></li> -->
                    <li><a href="contact-us.html">Contacto</a></li>

                </ul>
            </div>
            <div class="hamburger-menu d-lg-none"> <span></span> <span></span> <span></span> </div>
            <!--             <div class="navbar-button"> <a href="#"><i class="flaticon-contract iconp"></i>&nbsp;&nbsp;&nbsp;Get A
                    Quote</a> </div> -->
        </div>
    </nav>
    <header class="page-header wow fadeInUp" data-wow-delay="0.5s" data-background="img/page-header.jpg">
        <div class="container">
          <h2>
            <?php
            echo 'hola';
                if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['telefon']) && isset($_POST['message'])) {
            $ad = $_POST['name'];
            $email = $_POST['email'];
            $telefon = $_POST['telefon'];
            $mesaj = $_POST['message'];
        
            if (empty($ad) || empty($email) || empty($telefon) || empty($mesaj)) {
                echo 'Please do not leave blank';
            } else {
                $toEmail = 'rafaelpajuelot@gmail.com';
                $emailSubject = 'Nuevo correo electrónico desde tu formulario de contacto';
                $fromEmail = 'nevado@nevado.jadalsoftware.pe';
                $headers = "From: $fromEmail\r\n";
                $headers .= "Reply-To: $fromEmail\r\n";
                // Modifica el mensaje para incluir el número y el correo
                $fullMessage = "Nombre: $ad\n";
                $fullMessage .= "Correo Electrónico: $email\n";
                $fullMessage .= "Teléfono: $telefon\n";
                $fullMessage .= "Mensaje:\n$mesaj";
        
                // Envía el correo con el mensaje modificado
                mail($toEmail, $emailSubject, $fullMessage, $headers);
        
                echo 'Gracias';
            }
        } else {
            echo 'Por favor , rellene el formulario';
        }

            ?> 
          </h2>
          <div class="bosluk333"></div>
          <p>Aquí puedes volver al</p><br>
          <p><a href="index.html" class="custom-button"><strong>Inicio </strong></a> </p>
        </div>
        <!-- end container --> 
      </header>
        <main>
        </main>
            <!--Footer Alanı-->
            <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-4">
                    <div class="logo wow fadeInUp" data-wow-delay="0.1s"> <img src="img/logo2.png" alt="Image">
                    </div>
                    <!-- end logo -->
                    <div class="footer-info wow fadeInUp" data-wow-delay="0.2s">
                        <p><i class="flaticon-call iconpfooter"></i>&nbsp;&nbsp;&nbsp;073-336143</p><br>
                        <div class="bosluk04"></div>
                        <p><i
                                class="flaticon-email iconpfooter"></i>&nbsp;&nbsp;&nbsp;estaciondeservicionevado@gmail.com
                        </p><br>
                        <p><i class="flaticon-location iconpfooter"></i>&nbsp;&nbsp Esquina de Avs. Málaga y Country S/N
                            &nbsp;&nbsp;&nbspPiura</p>
                    </div>
                    <!-- end footer-info -->
                    <ul class="footer-social wow fadeInUp" data-wow-delay="0.3s">
                        <li><a href="#"><img width="25" height="25" src="img/facebook.png" alt="Facebook"></a></li>
                        <li><a href="#"><img width="25" height="25" src="img/instagram2.png" alt="Instagram"></a></li>
                        <li><a href="#"><img width="25" height="25" src="img/twitter.png" alt="Twitter"></a></li>
                    </ul>
                </div>
                <!-- end col-3 -->
                <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.4s">
                    <h6 class="widget-title">Suscríbase a nuestro boletín</h6>
                    <p class="footerp">
                        Suscríbete para estar informado sobre nuestros servicios y productos.
                    </p>
                    <div class="row">
                        <form action="subscribe.php" class="form__grup" method="post">
                            <div class="col-sm">
                                <div class="form__grup wow fadeInLeft" data-wow-delay="0.4s">
                                    <input type="email" class="form-popup__input" placeholder="Correo" id="email8"
                                        name="email8" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form__grup wow fadeInUp" data-wow-delay="0.5s">
                                    <button class="custom-button-form">Subscríbete →</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- end col-4 -->
                <div class="col-lg-2 offset-xl-1 col-sm-8 wow fadeInUp" data-wow-delay="0.1s">
                    <h6 class="widget-title">Servicios</h6>
                    <ul class="footer-menu">
                        <li><a href="estacion-servicio.html">Estación de Servicios</a></li>
                        <li><a href="energy-industry.html">Maquinas Pesadas</a></li>
                        <li><a href="servicio-carga.html"> Transporte de carga </a></li>

                    </ul>
                    <h6 class="widget-title">Intranet</h6>
                    <ul class="footer-menu">
                        <li><a href="https://www.facturacion.jadal.pe/auth" target="_blank"> Portal Fact.
                                Electrónica</a></li>
                        <li><a href="http://192.168.18.13:5173/" target="_blank">System Report</a></li>

                    </ul>
                </div>

            </div>
            <!-- end row -->
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 wow fadeInUp" data-wow-delay="0.9s">
                    <p class="copyright">© 2023 Jadal Software.</p>
                </div>
            </div>
        </div>
        <div id="top" style="cursor: pointer;">
            <img width="50" height="50" src="img/go-top.png" alt="" />
        </div>
        <script src="js/team.js"></script>
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/fancybox.min.js"></script>
        <script src="js/swiper.min.js"></script>
        <script src="js/odometer.min.js"></script>
        <script src="js/wow.min.js"></script>
        <script src="js/scripts.js"></script>
        <script src="js/3d.jquery.js"></script>

        <!--Cursor Script-->
        <script>
            init_pointer({
            })
        </script>
    </footer>
    </body>
  </html>